# Task-05 single-case independent audit — `scalar_monolithic_omega100_mode10_N12_dt5e-4_T10`

## Verdict: **PASS**

> This is a per-case integrity and scientific screening result. It does not replace the final multi-case Task-06 loader.

## Configuration

| Quantity | Value |
|---|---:|
| Propagator | `scalar_monolithic` |
| Detector label | `scalar` |
| Initial mode | `10` |
| Omega | 100 |
| N shell | 12 |
| M_N / spin channels | 91 / 182 |
| N_z | 1500 |
| dt | 0.0005 |
| T final | 10 |
| Backend | `cupy` |

## Provenance and structural gates

- Raw output manifest: **PASS**
- Configuration hash reconstruction: **PASS**
- Source-hash consistency: **PASS**
- Independent operator/source reconstruction: **PASS**
- Zero-bath/source-scope guard: **PASS**
- Positive `+K_N/(2 h_z)` source term found: **PASS**

## Detector and solver reductions

| Quantity | Value |
|---|---:|
| Final survival S(T) | 9.321669976013e-02 |
| Detected fraction from midpoint loss | 9.067833002395e-01 |
| Restricted mean mu*(T) | 4.135627918767e+00 |
| D_E (t < 3.6) | 5.856443053506e-01 |
| D_L (t >= 3.6) | 3.211389948889e-01 |
| Late fraction | 3.541518627483e-01 |
| Peak time / density | 2.464750000000e+00 / 3.682506404638e-01 |
| Roof closure residual | -3.401723347451e-13 |
| Roof closure relative | 3.751418168543e-13 |
| Minimum midpoint roof probability | 1.242335602177e-176 |
| Maximum survival increase | 4.551914400963e-15 |
| GMRES failures | 0 |
| Maximum true relative residual | 6.420897221183e-14 |

## Source and cutoff diagnostics

| Quantity | Value |
|---|---:|
| s_down(0) | 1.000000000000e+00 |
| s_phi(0) | 0.000000000000e+00 |
| s_up(0) | 3.000000000000e+00 |
| max s_down(t) | 1.000000000000e+00 |
| max s_phi(t) | 0.000000000000e+00 |
| min s_up(t) | 3.000000000000e+00 |
| max top-shell population | 0.000000000000e+00 |
| final omitted-K proxy integral | 0.000000000000e+00 |

## Deliberately pending until Task 06

- factorized scalar mode-null comparison (00,10,01)
- 10/01 spinor isotropy
- Cartesian--oscillator curve-level representation discrepancy
- monolithic scalar R_h/R_(h/2) convergence ratio
- spinor dt=5e-4 versus 2.5e-4 convergence
- spinor N=12 versus N=16 shell-cutoff convergence
- complete campaign-level stable same-prefix rerun decision

The raw solver directory must remain unchanged on the cluster. The share ZIP is sufficient for remote per-case review, but it is not a substitute for the raw files required by the final aggregate Task-06 loader.
