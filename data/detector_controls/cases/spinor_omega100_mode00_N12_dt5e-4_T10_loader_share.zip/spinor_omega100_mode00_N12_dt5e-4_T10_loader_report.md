# Task-05 single-case independent audit — `spinor_omega100_mode00_N12_dt5e-4_T10`

## Verdict: **PASS**

> This is a per-case integrity and scientific screening result. It does not replace the final multi-case Task-06 loader.

## Configuration

| Quantity | Value |
|---|---:|
| Propagator | `spinor` |
| Detector label | `spinor` |
| Initial mode | `00` |
| Omega | 100 |
| N shell | 12 |
| M_N / spin channels | 91 / 182 |
| N_z | 1500 |
| dt | 0.0005 |
| T final | 10 |
| Backend | `cupy` |

## Provenance and structural gates

- Raw output manifest: **PASS**
- Configuration hash reconstruction: **PASS**
- Source-hash consistency: **PASS**
- Independent operator/source reconstruction: **PASS**
- Zero-bath/source-scope guard: **PASS**
- Positive `+K_N/(2 h_z)` source term found: **PASS**

## Detector and solver reductions

| Quantity | Value |
|---|---:|
| Final survival S(T) | 4.861790483695e-01 |
| Detected fraction from midpoint loss | 5.138209516284e-01 |
| Restricted mean mu*(T) | 6.594333887834e+00 |
| D_E (t < 3.6) | 3.660436447100e-01 |
| D_L (t >= 3.6) | 1.477773069184e-01 |
| Late fraction | 2.876046732818e-01 |
| Peak time / density | 2.312750000000e+00 / 2.371160423219e-01 |
| Roof closure residual | -2.109201702183e-12 |
| Roof closure relative | 4.104935183141e-12 |
| Minimum midpoint roof probability | 1.223241282614e-176 |
| Maximum survival increase | 2.997602166488e-15 |
| GMRES failures | 0 |
| Maximum true relative residual | 7.000957532606e-14 |

## Source and cutoff diagnostics

| Quantity | Value |
|---|---:|
| s_down(0) | 0.000000000000e+00 |
| s_phi(0) | 0.000000000000e+00 |
| s_up(0) | 2.000000000000e+00 |
| max s_down(t) | 3.446303075620e-03 |
| max s_phi(t) | 6.692314341515e-03 |
| min s_up(t) | 2.000000000000e+00 |
| max top-shell population | 3.851015726510e-10 |
| final omitted-K proxy integral | 2.573120697912e-05 |

## Deliberately pending until Task 06

- factorized scalar mode-null comparison (00,10,01)
- 10/01 spinor isotropy
- Cartesian--oscillator curve-level representation discrepancy
- monolithic scalar R_h/R_(h/2) convergence ratio
- spinor dt=5e-4 versus 2.5e-4 convergence
- spinor N=12 versus N=16 shell-cutoff convergence
- complete campaign-level stable same-prefix rerun decision

The raw solver directory must remain unchanged on the cluster. The share ZIP is sufficient for remote per-case review, but it is not a substitute for the raw files required by the final aggregate Task-06 loader.
