# Task-05 single-case independent audit — `spinor_omega1_mode00_N12_dt1e-3_T10`

## Verdict: **PASS**

> This is a per-case integrity and scientific screening result. It does not replace the final multi-case Task-06 loader.

## Configuration

| Quantity | Value |
|---|---:|
| Propagator | `spinor` |
| Detector label | `spinor` |
| Initial mode | `00` |
| Omega | 1 |
| N shell | 12 |
| M_N / spin channels | 91 / 182 |
| N_z | 1500 |
| dt | 0.001 |
| T final | 10 |
| Backend | `cupy` |

## Provenance and structural gates

- Raw output manifest: **PASS**
- Configuration hash reconstruction: **PASS**
- Source-hash consistency: **PASS**
- Independent operator/source reconstruction: **PASS**
- Zero-bath/source-scope guard: **PASS**
- Positive `+K_N/(2 h_z)` source term found: **PASS**

## Detector and solver reductions

| Quantity | Value |
|---|---:|
| Final survival S(T) | 1.143836724731e-01 |
| Detected fraction from midpoint loss | 8.856163278776e-01 |
| Restricted mean mu*(T) | 4.258067788809e+00 |
| D_E (t < 3.6) | 5.761911959013e-01 |
| D_L (t >= 3.6) | 3.094251319763e-01 |
| Late fraction | 3.493895970932e-01 |
| Peak time / density | 2.453500000000e+00 / 3.622882034836e-01 |
| Roof closure residual | 3.507072410258e-10 |
| Roof closure relative | 3.960035852843e-10 |
| Minimum midpoint roof probability | 2.697548780024e-176 |
| Maximum survival increase | 2.997602166488e-15 |
| GMRES failures | 0 |
| Maximum true relative residual | 5.023878669140e-10 |

## Source and cutoff diagnostics

| Quantity | Value |
|---|---:|
| s_down(0) | 0.000000000000e+00 |
| s_phi(0) | 0.000000000000e+00 |
| s_up(0) | 2.000000000000e+00 |
| max s_down(t) | 1.606617074446e-01 |
| max s_phi(t) | 1.554593927920e-01 |
| min s_up(t) | 2.000000000000e+00 |
| max top-shell population | 8.636876214063e-13 |
| final omitted-K proxy integral | 3.772454439774e-11 |

## Deliberately pending until Task 06

- factorized scalar mode-null comparison (00,10,01)
- 10/01 spinor isotropy
- Cartesian--oscillator curve-level representation discrepancy
- monolithic scalar R_h/R_(h/2) convergence ratio
- spinor dt=5e-4 versus 2.5e-4 convergence
- spinor N=12 versus N=16 shell-cutoff convergence
- complete campaign-level stable same-prefix rerun decision

The raw solver directory must remain unchanged on the cluster. The share ZIP is sufficient for remote per-case review, but it is not a substitute for the raw files required by the final aggregate Task-06 loader.
