# Task-05 single-case independent audit — `spinor_omega100_mode01_N12_dt5e-4_T10`

## Verdict: **PASS**

> This is a per-case integrity and scientific screening result. It does not replace the final multi-case Task-06 loader.

## Configuration

| Quantity | Value |
|---|---:|
| Propagator | `spinor` |
| Detector label | `spinor` |
| Initial mode | `01` |
| Omega | 100 |
| N shell | 12 |
| M_N / spin channels | 91 / 182 |
| N_z | 1500 |
| dt | 0.0005 |
| T final | 10 |
| Backend | `cupy` |

## Provenance and structural gates

- Raw output manifest: **PASS**
- Configuration hash reconstruction: **PASS**
- Source-hash consistency: **PASS**
- Independent operator/source reconstruction: **PASS**
- Zero-bath/source-scope guard: **PASS**
- Positive `+K_N/(2 h_z)` source term found: **PASS**

## Detector and solver reductions

| Quantity | Value |
|---|---:|
| Final survival S(T) | 5.513087115551e-01 |
| Detected fraction from midpoint loss | 4.486912884438e-01 |
| Restricted mean mu*(T) | 7.150565663021e+00 |
| D_E (t < 3.6) | 2.851244157558e-01 |
| D_L (t >= 3.6) | 1.635668726880e-01 |
| Late fraction | 3.645421181572e-01 |
| Peak time / density | 2.293250000000e+00 / 1.864249603481e-01 |
| Roof closure residual | -1.021072115748e-12 |
| Roof closure relative | 2.275667350901e-12 |
| Minimum midpoint roof probability | 1.238308905179e-176 |
| Maximum survival increase | 4.662936703426e-15 |
| GMRES failures | 0 |
| Maximum true relative residual | 6.326219425056e-14 |

## Source and cutoff diagnostics

| Quantity | Value |
|---|---:|
| s_down(0) | 1.000000000000e+00 |
| s_phi(0) | 0.000000000000e+00 |
| s_up(0) | 3.000000000000e+00 |
| max s_down(t) | 1.000020863990e+00 |
| max s_phi(t) | 8.916202781929e-02 |
| min s_up(t) | 2.921447576786e+00 |
| max top-shell population | 1.514757866724e-08 |
| final omitted-K proxy integral | 1.021440268423e-03 |

## Deliberately pending until Task 06

- factorized scalar mode-null comparison (00,10,01)
- 10/01 spinor isotropy
- Cartesian--oscillator curve-level representation discrepancy
- monolithic scalar R_h/R_(h/2) convergence ratio
- spinor dt=5e-4 versus 2.5e-4 convergence
- spinor N=12 versus N=16 shell-cutoff convergence
- complete campaign-level stable same-prefix rerun decision

The raw solver directory must remain unchanged on the cluster. The share ZIP is sufficient for remote per-case review, but it is not a substitute for the raw files required by the final aggregate Task-06 loader.
