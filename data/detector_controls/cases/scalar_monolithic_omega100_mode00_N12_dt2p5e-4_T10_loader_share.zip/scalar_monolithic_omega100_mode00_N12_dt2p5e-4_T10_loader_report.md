# Task-05 single-case independent audit — `scalar_monolithic_omega100_mode00_N12_dt2p5e-4_T10`

## Verdict: **PASS**

> This is a per-case integrity and scientific screening result. It does not replace the final multi-case Task-06 loader.

## Configuration

| Quantity | Value |
|---|---:|
| Propagator | `scalar_monolithic` |
| Detector label | `scalar` |
| Initial mode | `00` |
| Omega | 100 |
| N shell | 12 |
| M_N / spin channels | 91 / 182 |
| N_z | 1500 |
| dt | 0.00025 |
| T final | 10 |
| Backend | `cupy` |

## Provenance and structural gates

- Raw output manifest: **PASS**
- Configuration hash reconstruction: **PASS**
- Source-hash consistency: **PASS**
- Independent operator/source reconstruction: **PASS**
- Zero-bath/source-scope guard: **PASS**
- Positive `+K_N/(2 h_z)` source term found: **PASS**

## Detector and solver reductions

| Quantity | Value |
|---|---:|
| Final survival S(T) | 9.311999091860e-02 |
| Detected fraction from midpoint loss | 9.068800090802e-01 |
| Restricted mean mu*(T) | 4.127779671092e+00 |
| D_E (t < 3.6) | 5.874752187179e-01 |
| D_L (t >= 3.6) | 3.194047903623e-01 |
| Late fraction | 3.522018207086e-01 |
| Peak time / density | 2.458875000000e+00 / 3.690457404804e-01 |
| Roof closure residual | -1.164290885924e-12 |
| Roof closure relative | 1.283842266083e-12 |
| Minimum midpoint roof probability | 5.438868791623e-177 |
| Maximum survival increase | 2.442490654175e-15 |
| GMRES failures | 0 |
| Maximum true relative residual | 9.877651683244e-15 |

## Source and cutoff diagnostics

| Quantity | Value |
|---|---:|
| s_down(0) | 0.000000000000e+00 |
| s_phi(0) | 0.000000000000e+00 |
| s_up(0) | 2.000000000000e+00 |
| max s_down(t) | 0.000000000000e+00 |
| max s_phi(t) | 0.000000000000e+00 |
| min s_up(t) | 2.000000000000e+00 |
| max top-shell population | 0.000000000000e+00 |
| final omitted-K proxy integral | 0.000000000000e+00 |

## Deliberately pending until Task 06

- factorized scalar mode-null comparison (00,10,01)
- 10/01 spinor isotropy
- Cartesian--oscillator curve-level representation discrepancy
- monolithic scalar R_h/R_(h/2) convergence ratio
- spinor dt=5e-4 versus 2.5e-4 convergence
- spinor N=12 versus N=16 shell-cutoff convergence
- complete campaign-level stable same-prefix rerun decision

The raw solver directory must remain unchanged on the cluster. The share ZIP is sufficient for remote per-case review, but it is not a substitute for the raw files required by the final aggregate Task-06 loader.
