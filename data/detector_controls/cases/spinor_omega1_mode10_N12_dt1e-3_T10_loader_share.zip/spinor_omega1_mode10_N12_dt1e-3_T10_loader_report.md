# Task-05 single-case independent audit — `spinor_omega1_mode10_N12_dt1e-3_T10`

## Verdict: **PASS**

> This is a per-case integrity and scientific screening result. It does not replace the final multi-case Task-06 loader.

## Configuration

| Quantity | Value |
|---|---:|
| Propagator | `spinor` |
| Detector label | `spinor` |
| Initial mode | `10` |
| Omega | 1 |
| N shell | 12 |
| M_N / spin channels | 91 / 182 |
| N_z | 1500 |
| dt | 0.001 |
| T final | 10 |
| Backend | `cupy` |

## Provenance and structural gates

- Raw output manifest: **PASS**
- Configuration hash reconstruction: **PASS**
- Source-hash consistency: **PASS**
- Independent operator/source reconstruction: **PASS**
- Zero-bath/source-scope guard: **PASS**
- Positive `+K_N/(2 h_z)` source term found: **PASS**

## Detector and solver reductions

| Quantity | Value |
|---|---:|
| Final survival S(T) | 1.343133604402e-01 |
| Detected fraction from midpoint loss | 8.656866398958e-01 |
| Restricted mean mu*(T) | 4.382943696609e+00 |
| D_E (t < 3.6) | 5.652168414636e-01 |
| D_L (t >= 3.6) | 3.004697984321e-01 |
| Late fraction | 3.470884088824e-01 |
| Peak time / density | 2.449500000000e+00 / 3.557161006769e-01 |
| Roof closure residual | 3.359561517868e-10 |
| Roof closure relative | 3.880805551386e-10 |
| Minimum midpoint roof probability | 2.699190452903e-176 |
| Maximum survival increase | 3.108624468950e-15 |
| GMRES failures | 0 |
| Maximum true relative residual | 4.932287595212e-10 |

## Source and cutoff diagnostics

| Quantity | Value |
|---|---:|
| s_down(0) | 1.000000000000e+00 |
| s_phi(0) | 0.000000000000e+00 |
| s_up(0) | 3.000000000000e+00 |
| max s_down(t) | 1.126469338670e+00 |
| max s_phi(t) | 2.669248465660e-01 |
| min s_up(t) | 3.000000000000e+00 |
| max top-shell population | 1.874100663946e-11 |
| final omitted-K proxy integral | 7.862787328245e-10 |

## Deliberately pending until Task 06

- factorized scalar mode-null comparison (00,10,01)
- 10/01 spinor isotropy
- Cartesian--oscillator curve-level representation discrepancy
- monolithic scalar R_h/R_(h/2) convergence ratio
- spinor dt=5e-4 versus 2.5e-4 convergence
- spinor N=12 versus N=16 shell-cutoff convergence
- complete campaign-level stable same-prefix rerun decision

The raw solver directory must remain unchanged on the cluster. The share ZIP is sufficient for remote per-case review, but it is not a substitute for the raw files required by the final aggregate Task-06 loader.
