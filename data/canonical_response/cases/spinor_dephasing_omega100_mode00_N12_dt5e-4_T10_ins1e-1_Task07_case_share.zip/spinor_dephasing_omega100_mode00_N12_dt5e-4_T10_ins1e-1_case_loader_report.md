# Task 07 — Independent per-case audit and share package

## Verdict: **FAIL**

> This is a read-only CPU audit of one completed Task-07 case. It does not import or rerun the solver and it does not itself authorize a physical susceptibility claim.

## Case and provenance

| Quantity | Value |
|---|---|
| Prefix | `spinor_dephasing_omega100_mode00_N12_dt5e-4_T10_ins1e-1` |
| Cluster case directory | `[ARCHIVE_PATH]` |
| Stage folder number | `4757` |
| Detector map | `spinor` |
| Environmental direction | `dephasing` |
| Confinement | 100 |
| Initial mode | `00` |
| Shell cutoff | 12 |
| Oscillator modes / spin channels | 91 / 182 |
| Longitudinal points | 1500 |
| Detector time step | 0.0005 |
| Observation horizon | 10 |
| Insertion spacing | 0.1 |
| Backend | `cupy` |
| Custom batched GMRES selected | `False` |
| GPU | `NVIDIA A100-SXM4-80GB` |
| Solver version | `2026-08-05-task07-environmental-response-v8-unified-manual-full-production` |
| Solver source SHA-256 | `3e880e13da576e87531551b8f0300d0cb9a1213f9bd8571dc6efcb902a542acb` |
| Numerical-core SHA-256 | `827fd4993707152393a8adcf891df59d7b4d02310a06e89dd5263c0fd37369af` |

## Runtime record

| Phase | Wall time / rate |
|---|---:|
| Input, operators, and reduced benchmark | 0 h 00 min 04 s |
| Task-05 archival regression reference | 0 h 02 min 53 s |
| Task-05 archival reference rate | 115.591 step/s |
| Matched Task-07 response reference | 0 h 02 min 53 s |
| Response reference rate | 115.732 step/s |
| Response reference reused Task-05 trajectory | `False` |
| Embedded selected-column closure guard | 0 h 32 min 13 s |
| Complete all-insertion kernel | 8 h 31 min 54 s |
| Total before final hashing | 9 h 09 min 57 s |

## Dual zero-rate reference and Task-05 recovery

| Quantity | Value |
|---|---:|
| Task-05 reference final survival | 4.861790483726e-01 |
| Task-05 reference maximum true residual | 7.000003532103e-14 |
| Response reference final survival | 4.861790483726e-01 |
| Response reference cumulative roof probability | 5.138209516301e-01 |
| Response-reference roof closure residual | 2.696287637605e-12 |
| Response-reference relative roof closure | 5.247523731858e-12 |
| Response-reference maximum true residual | 7.000003532103e-14 |
| Dual-reference complete-law distance | 0.000000000000e+00 |
| Dual-reference maximum selected-state relative difference | 1.673643486588e-16 |
| Dual-reference maximum roof-midpoint relative difference | 2.108788094412e-16 |
| Embedded-pilot maximum closure | 9.467822793124e-12 |
| Embedded-pilot maximum branch residual | 5.181354634316e-11 |
| Task-05 source directory | `[ARCHIVE_PATH]` |
| Task-05 case prefix | `spinor_omega100_mode00_N12_dt5e-4_T10` |
| Maximum survival recovery difference | 3.126054970437e-12 |
| Maximum step-probability recovery difference | 3.380948949624e-16 |

## Reconstructed environmental response

| Quantity | Value |
|---|---:|
| chi_D = -chi_S(T) | 4.578837853924e-03 |
| chi_D from panel sum | 4.578837893695e-03 |
| chi_mu | -2.974497781303e-02 |
| chi_D_E | 2.902018486976e-03 |
| chi_D_L | 1.676819406719e-03 |
| Complete signed-response norm | 4.685567466863e-03 |
| Maximum |chi_S| | 4.633792301594e-03 |
| Maximum |chi_g| | 1.907708383924e-03 |
| Launch activity / expected | 0.000000000000e+00 / 0.000000000000e+00 |

## Independent numerical controls

| Audit quantity | Value |
|---|---:|
| Source-trace residual | 1.131907068075e-16 |
| Tangent probability closure | 3.977138843952e-11 |
| Final detection-response identity residual | 3.977138583744e-11 |
| Per-insertion kernel closure | 1.844852547637e-11 |
| Maximum noncausal kernel entry | 0.000000000000e+00 |
| Minimum jump-kernel probability | 0.000000000000e+00 |
| Insertion signed-measure difference | 4.615431224309e-04 |
| Insertion relative difference | 9.807258679399e-02 |
| Insertion chi_mu relative difference | 9.883539209935e-03 |
| Full-tangent/low-rank survival difference | 9.264422860594e-23 |
| Full-tangent/low-rank panel difference | 3.308722450212e-24 |

## Operator and family status

| Item | Result |
|---|---|
| Audit-02 K permutation residual | 0.000000000000e+00 |
| K Hermiticity residual | 0.000000000000e+00 |
| Spinor roof +K sign residual | 0.000000000000e+00 |
| Detector-loss operator residual | 0.000000000000e+00 |
| Solver verdict | `FAIL` |
| Case role | `production_baseline` |
| Deterministic rerun passed | `False` |
| Time-step control | `PENDING` |
| Shell-cutoff control | `PENDING` |
| Evidence status | `PENDING` |
| Response classification | `None` |

## Interpretation

This case contains an active spinor response kernel. The per-case loader verifies its local integrity, dual-reference construction, embedded closure guard, and full-kernel reconstruction. The response remains provisional until Task 08 closes family convergence and the combined uncertainty budget.

## Independent checks

| Check | Verdict |
|---|---|
| `configuration.CAP_or_second_roof_loss_absent` | PASS |
| `configuration.automatic_production_sweep_absent` | PASS |
| `configuration.case_prefix_is_canonical` | PASS |
| `configuration.case_prefix_matches_filename` | PASS |
| `configuration.complete_insertion_grid_metadata_matches` | PASS |
| `configuration.configuration_hash_reconstructed` | PASS |
| `configuration.copied_solver_source_hash_matches` | PASS |
| `configuration.copied_solver_source_present` | PASS |
| `configuration.declared_closure_pilot_policy_consistent` | PASS |
| `configuration.declared_runtime_metrics_policy_consistent` | PASS |
| `configuration.explicit_detector_reservoir_absent` | PASS |
| `configuration.finite_positive_rate_absent` | PASS |
| `configuration.fixed_stage_directory_matches_actual_parent` | PASS |
| `configuration.manual_single_case_policy` | PASS |
| `configuration.manual_stage_folder_number_matches_actual_parent` | PASS |
| `configuration.output_contract_contains_required_products` | PASS |
| `configuration.production_contract_hash_reconstructed_when_declared` | PASS |
| `configuration.stage_exact` | PASS |
| `configuration.temperature_parameter_absent` | PASS |
| `configuration.trajectory_or_Monte_Carlo_absent` | PASS |
| `configuration.zero_environmental_rate_reference_exact` | PASS |
| `copied_solver_source_scope.passed` | PASS |
| `independent_numerical_reconstruction.all_declared_numeric_arrays_finite` | PASS |
| `independent_numerical_reconstruction.benchmark_NPZ_required_schema_present` | PASS |
| `independent_numerical_reconstruction.causal_kernel_triangle` | PASS |
| `independent_numerical_reconstruction.chi_response_reconstructed_from_kernel` | PASS |
| `independent_numerical_reconstruction.coarse_kernel_products_reconstructed` | PASS |
| `independent_numerical_reconstruction.declared_shapes_and_dtypes_exact` | PASS |
| `independent_numerical_reconstruction.expected_insertion_node_count` | PASS |
| `independent_numerical_reconstruction.final_detection_response_identity` | PASS |
| `independent_numerical_reconstruction.ground_state_launch_source_fingerprint` | PASS |
| `independent_numerical_reconstruction.independent_kernel_probability_closure` | PASS |
| `independent_numerical_reconstruction.insertion_quadrature_factor_two_refinement` | FAIL |
| `independent_numerical_reconstruction.insertion_time_grid_exact_including_final_stub` | PASS |
| `independent_numerical_reconstruction.integrated_response_reconstructed` | PASS |
| `independent_numerical_reconstruction.integrated_scalar_response_null` | PASS |
| `independent_numerical_reconstruction.jump_kernel_nonnegative` | PASS |
| `independent_numerical_reconstruction.kernel_NPZ_required_schema_present` | PASS |
| `independent_numerical_reconstruction.kernel_density_products_reconstructed` | PASS |
| `independent_numerical_reconstruction.kernel_insertion_steps_exact` | PASS |
| `independent_numerical_reconstruction.kernel_insertion_times_match_saved_grid` | PASS |
| `independent_numerical_reconstruction.kernel_total_equals_jump_plus_anticommutator` | PASS |
| `independent_numerical_reconstruction.panel_durations_positive_and_reconstructed` | PASS |
| `independent_numerical_reconstruction.pointwise_scalar_kernel_null` | PASS |
| `independent_numerical_reconstruction.reduced_full_tangent_low_rank_benchmark` | PASS |
| `independent_numerical_reconstruction.response_grid_reaches_observation_horizon` | PASS |
| `independent_numerical_reconstruction.source_NPZ_required_schema_present` | PASS |
| `independent_numerical_reconstruction.source_insertion_grid_matches_kernel` | PASS |
| `independent_numerical_reconstruction.source_shapes_exact` | PASS |
| `independent_numerical_reconstruction.source_trace_formulas_reconstructed` | PASS |
| `independent_numerical_reconstruction.tangent_probability_closure` | PASS |
| `independent_numerical_reconstruction.times_equal_insertion_times` | PASS |
| `independent_numerical_reconstruction.trace_preserving_environmental_insertion` | PASS |
| `loader_derived_metric_finiteness.no_nonfinite_required_loader_metrics` | PASS |
| `loader_scope.read_only_CPU_loader` | PASS |
| `manifest_and_files.all_manifest_file_hashes_match` | PASS |
| `manifest_and_files.all_required_solver_files_present` | PASS |
| `manifest_and_files.all_required_stable_products_listed_in_manifest` | PASS |
| `manifest_and_files.manifest_case_prefix_matches` | PASS |
| `manifest_and_files.manifest_configuration_hash_matches` | PASS |
| `manifest_and_files.manifest_nonempty` | PASS |
| `manifest_and_files.manifest_paths_confined_to_case_directory` | PASS |
| `manifest_and_files.manifest_source_hash_matches` | PASS |
| `manifest_and_files.runtime_metrics_excluded_from_deterministic_manifest` | PASS |
| `runtime_metrics.CuPy_GPU_metadata_present_when_required` | PASS |
| `runtime_metrics.Task05_reference_rate_reconstructed` | PASS |
| `runtime_metrics.declared_runtime_metrics_present` | PASS |
| `runtime_metrics.response_reference_rate_or_reuse_reconstructed` | PASS |
| `runtime_metrics.runtime_backend_matches_configuration` | PASS |
| `runtime_metrics.runtime_case_prefix_matches` | PASS |
| `runtime_metrics.runtime_durations_finite_and_nonnegative` | PASS |
| `runtime_metrics.runtime_record_excluded_from_deterministic_hashes` | PASS |
| `runtime_metrics.runtime_schema_supported` | PASS |
| `runtime_metrics.runtime_total_covers_all_recorded_components` | PASS |
| `solver_JSON_records.Task05_reference_comparison_metrics_rechecked` | PASS |
| `solver_JSON_records.Task05_reference_recovery_passed` | PASS |
| `solver_JSON_records.Task05_regression_reference_local_integrity_passed` | PASS |
| `solver_JSON_records.Task05_regression_reference_numerics_independently_rechecked` | PASS |
| `solver_JSON_records.all_solver_response_boolean_checks_pass` | FAIL |
| `solver_JSON_records.closure_pilot_file_matches_response_embedded_copy` | PASS |
| `solver_JSON_records.closure_pilot_file_present_when_declared` | PASS |
| `solver_JSON_records.dual_reference_consistency_metrics_rechecked_when_applicable` | PASS |
| `solver_JSON_records.dual_reference_consistency_passed_when_applicable` | PASS |
| `solver_JSON_records.embedded_closure_pilot_passed_and_rechecked` | PASS |
| `solver_JSON_records.operator_audit_passed` | PASS |
| `solver_JSON_records.operator_component_gates_rechecked` | PASS |
| `solver_JSON_records.reference_audit_passed` | PASS |
| `solver_JSON_records.response_audit_local_checks_passed` | FAIL |
| `solver_JSON_records.response_reference_and_branch_rtol_matched` | PASS |
| `solver_JSON_records.response_reference_local_integrity_passed` | PASS |
| `solver_JSON_records.response_reference_numerics_independently_rechecked` | PASS |
| `solver_JSON_records.solver_makes_no_production_physical_claim` | PASS |
| `status_and_stage_manifest.Task08_physical_claim_not_authorized_by_solver` | PASS |
| `status_and_stage_manifest.configuration_hash_matches_status` | PASS |
| `status_and_stage_manifest.output_manifest_filename_matches` | PASS |
| `status_and_stage_manifest.output_manifest_hash_matches_status` | PASS |
| `status_and_stage_manifest.solver_local_checks_reported_pass` | FAIL |
| `status_and_stage_manifest.solver_status_completed` | PASS |
| `status_and_stage_manifest.stage_manifest_case_entry_present` | PASS |
| `status_and_stage_manifest.stage_manifest_configuration_matches` | PASS |
| `status_and_stage_manifest.stage_manifest_operator_audit_matches` | PASS |
| `status_and_stage_manifest.stage_manifest_output_hashes_matches` | PASS |
| `status_and_stage_manifest.stage_manifest_reference_audit_matches` | PASS |
| `status_and_stage_manifest.stage_manifest_response_audit_matches` | PASS |
| `status_and_stage_manifest.stage_manifest_runtime_metrics_matches_when_declared` | PASS |
| `status_and_stage_manifest.stage_manifest_stage_exact` | PASS |
| `status_and_stage_manifest.stage_manifest_status_matches` | PASS |
| `status_and_stage_manifest.stage_manifest_verdict_matches` | PASS |

## Pending items

- deterministic same-prefix rerun
- external time-step/shell/evidence family

## Failed checks

- `independent_numerical_reconstruction.insertion_quadrature_factor_two_refinement`
- `solver_JSON_records.all_solver_response_boolean_checks_pass`
- `solver_JSON_records.response_audit_local_checks_passed`
- `status_and_stage_manifest.solver_local_checks_reported_pass`

## Share products

- Full raw-data package: `spinor_dephasing_omega100_mode00_N12_dt5e-4_T10_ins1e-1_Task07_case_share.zip`
- Compact diagnostic package: `spinor_dephasing_omega100_mode00_N12_dt5e-4_T10_ins1e-1_Task07_diagnostic_share.zip`
- The diagnostic package includes the loader audit, metrics and curve CSVs, compact NPZ, dual-reference/closure-pilot/response audits, status/runtime records, hashes, and optional logs.
- Task-05 raw archives and Task-07 temporary/rollback wave-function files are deliberately excluded.
